<div class="panel left-panel cf <?php echo (!$has_frames ? 'empty' : '') ?>">
  <?php $tpl->render($panel_left) ?>
</div>