<?php

namespace Maatwebsite\Excel\Concerns;

use PhpOffice\PhpSpreadsheet\Cell\IValueBinder;

interface WithCustomValueBinder extends IValueBinder
{
}
