<?php

namespace Maatwebsite\Excel\Exceptions;

use Throwable;

interface LaravelExcelException extends Throwable
{
}
