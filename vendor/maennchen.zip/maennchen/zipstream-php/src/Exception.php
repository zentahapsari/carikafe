<?php
declare(strict_types=1);

namespace ZipStream;

/**
 * This class is only for inheriting
 */
abstract class Exception extends \Exception
{
}
