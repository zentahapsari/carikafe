# Description of the problem

Please be very descriptive and include as much details as possible.

# Example code

# Informations

* ZipStream-PHP version:
* PHP version:

Please include any supplemental information you deem relevant to this issue.
